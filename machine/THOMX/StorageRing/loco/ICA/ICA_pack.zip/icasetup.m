%set up ICA paths

basedir = pwd;
% eval(['addpath ' basedir filesep 'gmatlib']);
% eval(['addpath ' basedir filesep 'mgui']);
