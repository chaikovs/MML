% NAFF toolbox
% Version 2.0 SOLEIL version 2007

