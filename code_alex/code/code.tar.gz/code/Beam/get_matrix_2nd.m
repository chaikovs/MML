function [dM]=get_matrix_2nd(de)
% return 6*6 chromatic second order terms dM (~approx for quad)
global  DYNAMIC ELEMENT

if nargin==0; de=1e-6 ; end
    

M0=DYNAMIC.matrix;
% step the QP strength
nel =length(ELEMENT); 
for i=1:nel
    type=ELEMENT(i).type;
    if strcmp(type,'QP')
        ELEMENT(i).strength=ELEMENT(i).strength*(1+de);
    end 
end
lattice_fill;
M1=DYNAMIC.matrix;
dM=(M0-M1)/de;

% Restore QP strength
for i=1:nel
    type=ELEMENT(i).type;
    if strcmp(type,'QP')
        ELEMENT(i).strength=ELEMENT(i).strength/(1+de);
    end 
end

end