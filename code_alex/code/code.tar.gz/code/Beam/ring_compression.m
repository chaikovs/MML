% test ring compression effect
% cas CLS 50 MeV
% from RF strength



%input data from gun
sigs=1.2e-3; 
sige_uncor=5e-4;


% ring data
c=3e8;
E   = 50;      %MeV
E0  =0.511;
Frf = 500e6;   % freq cavity
kl=2*pi*Frf/c;
Vrf =0.3;       % energy gain in MeV
phi0=pi/2;       % synchronous phases (no losses)
r56=-2*1.2127;

r65=kl*Vrf*sin(phi0)/E;
c  =1+r56*r65/2;


bmax=-r56/sqrt(1-c^2);
bmin=-sqrt(1-c^2)/r65;
ratio=1+0.25*r56*r65;
Vmax =-4*E/r56/kl;



fprintf('##########################\n');
% make ring matrix
[M]=get_matrix_long(r56,E,Vrf,Frf,phi0,2);
[sigs1,ep1,bs1,as1,gs1]=get_beam_long(3e-3,M);
fprintf('bs min at mid r56        %d \n',bs1);

[M]=get_matrix_long(r56,E,Vrf,Frf,phi0,4);
[sigs2,eps2,bs2,as2,gs2]=get_beam_long(3e-3,M);
fprintf('bs max at mid cavity     %d \n',bs2);

fprintf('ratio bs min / max       %d \n',bs1/bs2);

