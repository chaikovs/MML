function [phasespace]=dipole_test(phasespace,l,r) 
% non Exact dipole pass, sector only
% From hamiltonian integation with long radius approx(ex. Nadolski theses)
% r = radius m
% teta= angle rad

h=1/r;

%
x =phasespace(1,:);
xp=phasespace(2,:);
z =phasespace(3,:);
zp=phasespace(4,:);
s =phasespace(5,:);
d =phasespace(6,:);
%
kx=h./sqrt(1+d);



cx=cos(kx*l);sx=sin(kx*l);
r16=(1-cx)./h;r26=sx.*kx/h;

x1 = x.*cx     +  xp.*sx./kx  + r16.*d;
xp1=-x.*kx.*sx +  xp.*cx      + r26.*d;
z1 = z + l*zp;



phasespace(1,:)=x1;
phasespace(2,:)=xp1;
phasespace(3,:)=z1;


return
    
