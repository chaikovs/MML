% example add an RF
%lattice_beta2code;

global ELEMENT LATTICE0 LATTICE
nel=length(ELEMENT);nlat=length(LATTICE0);
%
nelem=element_RF('RF',50,0.4,5e8,pi/2); % new element
lattice_fill
nel1=length(ELEMENT);nlat1=length(LATTICE0);

fprintf('ELEMENT %d  -> %d \n',nel,nel1)
fprintf('LATTICE %d  -> %d \n',nlat,nlat1)

LATTICE(nlat1).matrix