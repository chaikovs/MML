% Example 
% Run beta2code before and get Structure ELEMENT, LATTICE and DYNAMIC 
global ELEMENT LATTICE0 DYNAMIC
%
twiss0=DYNAMIC.twiss; %input
fprintf('Beta matrix at begin')
twiss0

% Get beta matrix at element 12
M=eye(6);nelem=12;
for i=1:nelem
    num=LATTICE(i).num;
    [T]=matrix_element(ELEMENT(num).type,ELEMENT(num).length,ELEMENT(num).strength,ELEMENT(num).div);
    M=T*M;
end
fprintf('Beta matrix at elemnt %d ',nelem)
twiss=M*twiss0*M'


% Get beta matrix at end
M=eye(6);nelem=length(LATTICE);
for i=1:nelem
    num=LATTICE(i).num;
    [T]=matrix_element(ELEMENT(num).type,ELEMENT(num).length,ELEMENT(num).strength,ELEMENT(num).div);
    M=T*M;
end
fprintf('Beta matrix at end ')
twiss=M*twiss0*M'


