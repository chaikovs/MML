function [MCX,MCZ,nhp,nvp,nhc,nvc]=err_corr_eff_matrix
% Get CORR and BPM index on lattice (nhp,nvp,nhc,nvc)
% Get H & V matrix to reverse  (MCX MCZ) hc1 hc2 etc ...
% (x1 x2 etc ) = MCX (hc1 hc2 etc ...) for each BPM
% corr values given by -inv(MCX)*(x_nocorr)
% Works for a line (not a ring)
global  LATTICE

nel =length(LATTICE); 
% Get CORR and BPM index on lattice
ihc=0;ivc=0;ihp=0;ivp=0;
for i=1:nel
    type=LATTICE(i).type;
    if strcmp(type,'HC');ihc=ihc+1;nhc(ihc)=i;end % corr H
    if strcmp(type,'VC');ivc=ivc+1;nvc(ivc)=i;end % corr V
    if strcmp(type,'HP');ihp=ihp+1;nhp(ihp)=i;end %  bpm H
    if strcmp(type,'VP');ivp=ivp+1;nvp(ivp)=i;end %  bpm V
end

% if or(ihc==0,ivc==0,ihp==0,ivp==0)
%     MCX=0;MCZ=0;nhc=0;nvc=0;
%     return
% end

% Get H matrix to reverse
MCX=zeros(length(nhc),length(nhp));
for i=1:length(nhc)
    n1=nhc(i);
    for j=1:length(nhp)
        n2=nhp(j);
        T=eye(6,6);
        for k=n1:n2;T=squeeze(LATTICE(k).matrix)*T;end
        MCX(j,i)=T(1,2);
    end
end

% Get V matrix to reverse
MCZ=zeros(length(nvc),length(nvp));
for i=1:length(nvc)
    n1=nvc(i);
    for j=1:length(nvp)
        n2=nvp(j);
        T=eye(6,6);
        for k=n1:n2;T=squeeze(LATTICE(k).matrix)*T;end
        MCZ(j,i)=T(3,4);
    end
end
