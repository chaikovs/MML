function example_add_RF(V,Freq,phase,pelem)
% example add an RF
%lattice_beta2code;
global ELEMENT LATTICE0 DYNAMIC

if nargin == 0 ;
  V   =0.300;
  Freq=0.5e9;
  phase=pi/2;
  pelem=55; %+24;  % +24 with Qff
end

nel=length(ELEMENT);nlat=length(LATTICE0);
%
E   =DYNAMIC.energy;
nelem=element_RF('CAV',E,V,Freq,phase); % new element
%lattice_insert(nelem,1)  
lattice_insert(nelem,pelem); 
lattice_fill;
nel1=length(ELEMENT);nlat1=length(LATTICE0);
%
fprintf('RF added at element %f \n',pelem)
%
fprintf(' ELEMENT %d  -> %d \n',nel,nel1)
fprintf(' LATTICE %d  -> %d \n',nlat,nlat1)
%
nus=get_tune;
fprintf(' Tunes x,z,s,-> %4.2f  %4.2f  %6.4f \n',nus)