function [x,s_mean,s_rms,s_q]=bunch_Vslice_surf(phasespace,nbin,w,dx)
% Comput mean, rms  from screen vertical slice 
% nbin    : number of slice
% w half window size x & z
% data are table of size (param,nbin)
% s_mean  : mean of the 6 variables  (6,nbin)
% s_rms   : std of the 6 variables   (6,nbin)

% rms semble buggé !


phimax1=w(1);
[phasespace]=acceptance(phasespace,1,phimax1);
phimax3=w(2);
[phasespace]=acceptance(phasespace,3,phimax3);

% X Z plane
% Mesh over X
phi1=phasespace(1,:);
step1=(2*phimax1)/nbin;
grille1=(-phimax1:step1:phimax1) + mean(phi1);

% Mesh over Z
phi3=phasespace(3,:);
step3=(2*phimax3)/nbin;
grille3=(-phimax3:step3:phimax3) + mean(phi3);

% imported from the net
[CXZ] = hist2(phi1,phi3,grille1,grille3);
b=2;h=ones(b)/b^2;
CXZ=filter2(h,CXZ);
n=length(grille1);
CXZ=CXZ(1:n,1:n);


%Get sum, mean and rms on vertical
s_q=sum(CXZ); 
Z=(ones(n,1)*grille3)';
s_mean=mean(CXZ.*Z)./s_q*nbin;
Zm=(ones(n,1)*s_mean);
s_rms=mean(CXZ.*(Z-Zm).^2)./s_q*nbin;
s_rms=sqrt(s_rms);


figure(1)
subplot(3,1,1)
ncolor=128;
mm=floor(max(max(CXZ+1))); % to fit color map
CXZ=CXZ*ncolor/mm;
CmapXZ=jet(ncolor);
%C(1,:)=0;  % force background to black
CmapXZ(1,:)=1;  % force background to white
set(gca,'FontSize',16)
image(grille1*1e3,grille3*1e3,CXZ)
xlim([-phimax1 phimax1]*1e3)
colormap(CmapXZ)
set(gca,'YDir','normal')
xlabel('X (mm)');ylabel('Z (mm)'); grid on;

if nargin==3
    subplot(3,1,2)
    set(gca,'FontSize',16)
    plot(grille1*1e3,s_q(1:n),'LineWidth',2)
    xlim([-phimax1 phimax1]*1e3)
    xlabel('X (mm)');ylabel('Density (u.a.)'); grid on;
    
    subplot(3,1,3)
    set(gca,'FontSize',16)
    plot(grille1*1e3,s_rms(1:n)*1e3,'LineWidth',2)
    xlim([-phimax1 phimax1]*1e3)
    xlabel('X (mm)');ylabel('Z rms (mm)'); grid on;
    x =grille1;
elseif nargin==4
    subplot(3,1,2)
    set(gca,'FontSize',16)
    plot(grille1*1e2/dx,s_q(1:n),'LineWidth',2)
    xlim([-phimax1 phimax1]*1e2/dx)
    xlabel('dE (%)');ylabel('Density (u.a.)'); grid on;
    
    subplot(3,1,3)
    set(gca,'FontSize',16)
    plot(grille1*1e2/dx,s_rms(1:n)*1e3,'LineWidth',2)
    xlim([-phimax1 phimax1]*1e2/dx)
    xlabel('dE (%)');ylabel('Z rms (mm)'); grid on;  
    x =grille1/dx;
end



return