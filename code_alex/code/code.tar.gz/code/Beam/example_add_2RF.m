% example add an RF
lattice_beta2code;
global ELEMENT LATTICE0 DYNAMIC

nel=length(ELEMENT);nlat=length(LATTICE0);
%
V=0.280;
nelem=element_RF('RF1',50,V/2,0.5e9,pi/2); % new element
lattice_insert(nelem,1)  
nelem=element_RF('RF2',50,V/2,0.5e9,pi/2); % new element
lattice_insert(nelem,nlat+2)  
% add at end of lattice
nel1=length(ELEMENT);nlat1=length(LATTICE0);
%
fprintf('ELEMENT %d  -> %d \n',nel,nel1)
fprintf('LATTICE %d  -> %d \n',nlat,nlat1)

nus=get_tune;
fprintf('Tunes x,z,s,-> %4.3f  %4.3f  %4.3f \n',nus)

