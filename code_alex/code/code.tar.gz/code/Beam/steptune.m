function [phasespace]=steptune(phasespace,twiss,disp,dnux,dnuz)
% steptune in H & V
% add a dnu artificially in phase space
% remove disp and offset first and add after rotation


% % remove dispersion correlation for x,xp z zp
% phasespace(1:4,:)=phasespace(1:4,:) - disp(1:4)*phasespace(6,:);
% 
% % remove mean value to center
% mm=mean(phasespace(1:4,:) ,2);
% for i=1:4
%     phasespace(i,:)=phasespace(i,:) - mm(i);
% end


% step tunex by dnux
p=dnux*2*pi;c=cos(p);s=sin(p);
b=twiss(1);a=-twiss(2);g=(1+a^2)/b;
T=[c+a*s b*s ; -g*s c-a*s]
phasespace(1:2,:)=T*phasespace(1:2,:);

% step tunez by dnuz
p=dnuz*2*pi;c=cos(p);s=sin(p);
b=twiss(3);a=-twiss(4);g=(1+a^2)/b;
T=[c+a*s b*s ; -g*s c-a*s]
phasespace(3:4,:)=T*phasespace(3:4,:);


% %add mean value to center
% for i=1:4
%     phasespace(i,:)=phasespace(i,:) + mm(i);
% end
% 
% % add dispersion correlation for x,xp z zp
% phasespace(1:4,:)=phasespace(1:4,:) + disp(1:4)*phasespace(6,:);

end