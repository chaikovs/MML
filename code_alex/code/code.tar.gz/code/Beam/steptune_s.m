function [phasespace]=steptune_s(phasespace,twiss,dnus)
% steptune in L
% add a dnu artificially in phase space
% remove disp and offset first and add after rotation


% remove r51 r52 correlation for s de/e to be done
%phasespace(1:4,:)=phasespace(1:4,:) - disp(1:4)*phasespace(6,:);

%remove mean value to center
mm=mean( phasespace(1:6,:) ,2);
for i=5:6
    phasespace(i,:)=phasespace(i,:) - mm(i);
end

% step tunex by nux
p=dnus*2*pi;c=cos(p);s=sin(p);
b=twiss(1);a=twiss(2);g=(1+a^2)/b;  % to check why a=twiss(2)/2 instead off  a=-twiss(2)
T=[c+a*s b*s ; -g*s c-a*s];
phasespace(5:6,:)=T*phasespace(5:6,:);

%add mean value to center
for i=5:6
    phasespace(i,:)=phasespace(i,:) + mm(i);
end

% add  r51 r52 correlation for s de/e to be done
%phasespace(1:4,:)=phasespace(1:4,:) + disp(1:4)*phasespace(6,:);

end