function [T]=matrix_diph(L,R,n)
% give 6*6 transfert matrix for dipole
% L length m
% R radius
% n indice
% E

n=0; % forced
h=1/R;
kx=sqrt((1-n)*h^2);
ky=sqrt(n*h^2);

if n==0
    cx=cos(kx*L);sx=sin(kx*L);cy=1;sy=0;
    r16=h*(1-cx)/kx/kx;r26=h*sx/kx;
    r51=-r26;r52=-r16;
    r56=-h*h*(kx*L-sx)/kx/kx/kx;
    T=[cx  sx/kx  0   0   0   r16 ; ...
      -kx*sx cx   0   0   0   r26 ; ...
        0     0    1   L   0   0 ; ...
        0     0    0   1   0   0 ; ...
       r51  r52    0   0   1   r56 ; ...
        0     0    0   0   0   1];
else % A verifier
    cx=cos(kx*L);sx=sin(kx*L);cy=cosh(ky*L);sy=sinh(ky*L);
    r16=h*(1-cx)/kx/kx;r26=h*sx/kx;
    r51=-r26;r52=-r16;
    r56=-h*h*(kx*L-sx)/kx/kx/kx;
    T=[cx  sx/kx  0   0   0   r16 ; ...
      -kx*sx cx   0   0   0   r26 ; ...
        0     0    cy   sy/ky   0   0 ; ...
        0     0    -ky*sy   cy   0   0 ; ...
       r51  r52    0   0   1   r56 ; ...
        0     0    0   0   0   1];
end
return