function y=fpp(x,s,k)
y=6*x*s/k^1.5-x^4+3;