
[phasespace,grille,profil,wake,green,U]=broadband_wake(phasespace,q,BB,E)
[phasespace,grille,profil,wake,green,U]=csr_wake(phasespace,q,R,E,L);
[phasespace,grille,profil,wake,green,U]=csr_wake_edge(phasespace,q,R,E,L,Ls);
[phasespace,grille,profil,wake,green,U,r]=csr_wake_shielded(phasespace,q,R,h,E,L);
[phasespace,grille,profil,wake,green,U]=lsc_wake(phasespace,q,E,E0,L);
[phasespace,grille,profil,wake,U]=RL_wake(phasespace,q,Rr,Li,E);
[phasespace,grille,profil,wake,green,U]=RW_wake(phasespace,q,sig,b,E,L)

