function make_path

dir0=pwd;
dir0='/home/sources/physmach/loulergue/work/code';
dir1=[dir0 '/Beam'];
dir2=[dir0 '/Wake'];
dir3=[dir0 '/Compton'];
dir4=[dir0 '/SR'];
dir5=[dir0 '/Diags'];
dir6=[dir0 '/FEL'];
dir7=[dir0 '/Genesis'];
dir8=[dir0 '/SRW'];
dir9=[dir0 '/ASTRA'];
addpath(dir1,dir2,dir3,dir4,dir5,dir6,dir7,dir8,dir9);